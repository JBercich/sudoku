# Data Governance

There is plenty of available data on the internet. `t-dillon` has a good collection of puzzle files with profiles against a few of them. See [https://github.com/t-dillon/tdoku](https://github.com/t-dillon/tdoku) for the original data. Some changes made in this repo:

- Removed top-level file information and moved to here.
- Replaced `.` with `0` for missing cell value encodings.

| File       | Metadata                                                                                                              |
| ---------- | --------------------------------------------------------------------------------------------------------------------- |
| `puzzles0` | [See here](https://www.kaggle.com/datasets/bryanpark/sudoku).                                                         |
| `puzzles1` | No information provided. Likely a modification of `puzzles0`.                                                         |
| `puzzles2` | Puzzles with 17 clues. [See here](http://staffhome.ecm.uwa.edu.au/~00013890/sudokumin.php).                           |
| `puzzles3` | `magictour_top1465`. [See here](http://magictour.free.fr/sudoku.htm).                                                 |
| `puzzles4` | `forum_hardest_1905`. [See here](http://forum.enjoysudoku.com/the-hardest-sudokus-new-thread-t6539-600.html#p277835). |
| `puzzles5` | `forum_hardest_1905_11+`. No information provided. Likely a modification of `puzzles4`.                               |
| `puzzles6` | `forum_hardest_1106`. [See here](http://forum.enjoysudoku.com/the-hardest-sudokus-new-thread-t6539-600.html#p277835). |
| `puzzles7` | `sert_benchmark`. [See here](http://sites.google.com/site/sergsudoku/benchmark.zip).                                  |
| `puzzles8` | `gen_puzzles`. [See here](http://www.enjoysudoku.com/gen_puzzles.zip).                                                |
